import axios from 'axios';
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function AddUsers() {
    let navigate = useNavigate();
    const [users, setUsers] = useState({
        name: "",
        username: "",
        email: ""
    });

    const [errors, setErrors] = useState({});

    const { name, username, email } = users;

    const validateForm = () => {
        const newErrors = {};

        // Name validation
        if (!name.trim()) {
            newErrors.name = "Name is required";
        } else if (name.trim().length < 3) {
            newErrors.name = "Name must be at least 3 characters long";
        } else if (!/^[A-Za-z\s]+$/.test(name.trim())) {
            newErrors.name = "Name should contain only letters and spaces";
        }

        // Username validation
        if (!username.trim()) {
            newErrors.username = "Username is required";
        } else if (username.trim().length < 4) {
            newErrors.username = "Username must be at least 4 characters long";
        } else if (!/^[A-Za-z0-9_]+$/.test(username.trim())) {
            newErrors.username = "Username can only contain letters, numbers, and underscores";
        }

        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email.trim()) {
            newErrors.email = "Email is required";
        } else if (!emailRegex.test(email.trim())) {
            newErrors.email = "Please enter a valid email address";
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const onInputChange = (e) => {
        const { name, value } = e.target;
        setUsers({...users, [name]: value});
        
        // Clear specific field error when user starts typing
        if (errors[name]) {
            setErrors({...errors, [name]: ''});
        }
    };

    const onSubmit = async (e) => {
        e.preventDefault();
        
        // Validate form before submission
        if (validateForm()) {
            try {
                await axios.post("http://localhost:8080/users", users);
                navigate("/");
            } catch (error) {
                // Handle API submission error
                alert("Error submitting form: " + error.message);
            }
        }
    };

    const handleReset = () => {
        setUsers({
            name: "",
            username: "",
            email: ""
        });
        setErrors({});
    };

    return (
        <div>
            <div className="container">
                <div className="row">
                    <div className="col-sm-6 offset-md-3 border rounded p-4 mt-2 shadow">
                        <h2 className="text-center m-4">Register User</h2>
                        <div className="mb-3">
                            <form onSubmit={onSubmit}>
                                <div className="form-group">
                                    <label htmlFor="name">Name:</label>
                                    <input 
                                        type="text" 
                                        className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                                        id="name" 
                                        placeholder="Enter name" 
                                        name="name" 
                                        value={name}
                                        onChange={onInputChange}
                                    />
                                    {errors.name && (
                                        <div className="invalid-feedback">
                                            {errors.name}
                                        </div>
                                    )}
                                </div>
                                <div className="form-group">
                                    <label htmlFor="username">Username:</label>
                                    <input 
                                        type="text" 
                                        className={`form-control ${errors.username ? 'is-invalid' : ''}`}
                                        id="username" 
                                        placeholder="Enter username" 
                                        name="username" 
                                        value={username}
                                        onChange={onInputChange}
                                    />
                                    {errors.username && (
                                        <div className="invalid-feedback">
                                            {errors.username}
                                        </div>
                                    )}
                                </div>
                                <div className="form-group">
                                    <label htmlFor="email">Email:</label>
                                    <input 
                                        type="email" 
                                        className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                                        id="email" 
                                        placeholder="Enter email" 
                                        name="email" 
                                        value={email}
                                        onChange={onInputChange}
                                    />
                                    {errors.email && (
                                        <div className="invalid-feedback">
                                            {errors.email}
                                        </div>
                                    )}
                                </div>
                                <button type="submit" className="btn btn-primary">Submit</button>
                                <button 
                                    type="button" 
                                    className="btn btn-outline-danger mx-2"
                                    onClick={handleReset}
                                >
                                    Reset
                                </button>
                                <Link className="btn btn-primary" to="/">Home</Link>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}