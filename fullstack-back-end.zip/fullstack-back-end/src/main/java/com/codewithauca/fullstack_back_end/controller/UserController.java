package com.codewithauca.fullstack_back_end.controller;

import com.codewithauca.fullstack_back_end.exception.UserNotFoundException;
import com.codewithauca.fullstack_back_end.model.User;
import com.codewithauca.fullstack_back_end.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:3004")
public class UserController {
    @Autowired
    private UserRepository userRepository;
    @PostMapping("/users")
    User newUser (@RequestBody User newUser){
     return userRepository.save(newUser);
    }
    @GetMapping("/users")
    Iterable<User> getAllUsers(){
        return userRepository.findAll();
    }
    @GetMapping("/users/{id}")
    public User getUserById(@PathVariable Long id) {
        return userRepository.findById(id)
                .orElseThrow(()-> new UserNotFoundException(id));
    }
    @PutMapping("users/{id}")
    User updateUser(@RequestBody User newuser, @PathVariable Long id){
        return userRepository.findById(id)
                .map(user-> {
                    user.setName(newuser.getName());
                    user.setUsername(newuser.getUsername());
                    user.setEmail(newuser.getEmail());
                    return userRepository.save(user);
                })
                .orElseThrow(()-> new UserNotFoundException(id));
    }
    @DeleteMapping("/users/{id}")
    String deleteUser(@PathVariable Long id){
        if (!userRepository.existsById(id)){
            throw new UserNotFoundException(id);
        }
        userRepository.deleteById(id);
        return "User deleted successfully "+id+" ";
    }

}
