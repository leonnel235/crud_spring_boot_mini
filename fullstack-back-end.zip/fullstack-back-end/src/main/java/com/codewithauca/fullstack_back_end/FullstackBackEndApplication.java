package com.codewithauca.fullstack_back_end;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FullstackBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(FullstackBackEndApplication.class, args);
	}

}
