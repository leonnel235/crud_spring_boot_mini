package com.codewithauca.fullstack_back_end.exception;

public class UserNotFoundException  extends RuntimeException{
    public UserNotFoundException( Long id) {
        super("Could not find user " + id);

    }
}
