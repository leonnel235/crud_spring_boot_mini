package com.codewithauca.fullstack_back_end;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullstackBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
